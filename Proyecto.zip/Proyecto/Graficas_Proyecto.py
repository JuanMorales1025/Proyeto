import pandas as pd
import matplotlib.pyplot as plt

df_ciudad = pd.read_csv("Ciudad.csv")
df_cliente = pd.read_csv("Cliente.csv")
df_material = pd.read_csv("Material.csv")
df_producto = pd.read_csv("Producto.csv")
df_proveedor = pd.read_csv("Proveedor.csv")
df_red = pd.read_csv("Red de conocimiento.csv")
df_tipo = pd.read_csv("Tipo de producto.csv")
df_transportadora = pd.read_csv("Transportadora.csv")
df_datos_envio = pd.read_csv("Datos Envio.csv")
df_numero_pedidos = pd.read_csv("Numero de pedidos.csv")
df_factura = pd.read_csv("Factura.csv")
df_ingreso_prod = pd.read_csv("Ingreso de producto.csv")


merged_inner = pd.merge(left=df_cliente,right=df_numero_pedidos, left_on='Id', right_on='id_cliente')
merged_inner.plot.bar(x = 'Nombre',y  = ' numero_pedidos')

df_ingreso_prod['Id Proveedor'].value_counts().plot.bar()

df_cliente['Id de Ciudad'].value_counts().plot.bar()

fig2 = df_factura['Id producto'].value_counts()
fig2.columns = ['Id producto','Compras']
fig2.plot(kind = 'bar', width=0.5,figsize=(9,5))